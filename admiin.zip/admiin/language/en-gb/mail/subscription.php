<?php
// Text
$_['text_subject']             = '%s - Subscription';
$_['text_subscription_id']     = 'Subscription ID';
$_['text_date_added']          = 'Subscription Date:';
$_['text_subscription_status'] = 'Your subscription has been added to the following status:';
$_['text_comment']             = 'The comments for your subscription are:';
$_['text_payment_method']      = 'Payment Method';
$_['text_payment_code']        = 'Payment Code';
$_['text_footer']              = 'Please reply to this email if you have any questions.';
